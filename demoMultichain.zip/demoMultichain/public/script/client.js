var hostName = "localhost";
var baseURL = "http://" + hostName + ":8000/";
var _address = "1XHKk4iW2TFvbeysjhQS36GnHuxGkpzLLzkTFs";
var flag = true;

function raterequest() {
    var url = baseURL + "RateRequest";
    $.ajax({
        type: "get",
        url: url,
    });
}

function el(ID) {
    return document.getElementById(ID);
}

function d2h(d) {
    return d.toString(16);
}
function h2d(h) {
    return parseInt(h, 16);
}
function stringToHex(tmp) {
    var str = '',
        i = 0,
        tmp_len = tmp.length,
        c;

    for (; i < tmp_len; i += 1) {
        c = tmp.charCodeAt(i);
        str += d2h(c) + ' ';
    }
    return str;
}
function hex2a(hexx) {
    var hex = hexx.toString();//force conversion
    var str = '';
    for (var i = 0; i < hex.length; i += 2)
        str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
    return str;
}

//////////////////////////////////////////////
//called from Client.js
//////////////////////////////////////////////
function sendPostData(URL, jsonData) {
    $.ajax({
        type: "POST",
        url: URL,
        async: false,
        contentType: "application/json; charset=utf-8",
        data: jsonData,
        success: function (response) {
            alert("Data saved");
            getListlatestdataRequest();
        },
    });
}

///////////////////////////////////
// publish data from RateRequest//
//////////////////////////////////
function saveRateOfRequestPublish() {
    var flag = validation();
    if (flag == false) {
        var rateID = el("rr_no").value;
        var date = el("rr_date").value;
        var requestBy = el("rr_by").value;
        var customer = el("customer").value;
        var enquiryNO = el("enquiry_no").value;
        var enquiryDate = el("enquiry_date").value;
        var shipmentDate = el("shipment_date").value;
        var term = el("inco_terms").value;
        var salePerson = el("sales_persion").value;
        var validFrom = el("valid_from_date").value;
        var validTO = el("valid_to_date").value;
        var agency = el("agency").value;
        var shipper = el("shipper").value;
        var consignee = el("consignee").value;
        var status = el("Status").value;
        var shipmentTerm = el("shipment_term").value;
        var shipmentLine = el("shipment_line").value;
        if (rateID != null) {
            var RateOfRequest = {
                "RateID": rateID, "RateDate": date, "RequestBy": requestBy, "Customer": customer,
                "EnquiryNO": enquiryNO, "EnquiryDate": enquiryDate, "ShipmentDate": shipmentDate, "Term": term, "SalePerson": salePerson,
                "ValidFrom": validFrom, "ValidTO": validTO, "Agency": agency, "Shipper": shipper, "Consignee": consignee, "Satus": status,
                "ShipmentTerm": shipmentTerm, "ShipmentLine": shipmentLine
            }
            data = JSON.stringify(RateOfRequest);
            var parseData = stringToHex(data).replace(/\s/g, "");
            //var parseData = stringToHex(data);
            var rateOfReq = { "RateID": rateID, "RefName": rateID, "Address": _address, "EncData": parseData }
            data = JSON.stringify(rateOfReq);

            var url = baseURL + "CreateRequest";
            console.log(url);
            sendPostData(url, data);

        }
        else {
            alert("No Data");
        }
    }
}

////////////////////////////////
// Request list from RateRequest
///////////////////////////////
function getListlatestdataApproved() {
    var url = baseURL + "listlatestdata";
    $.ajax({
        type: "Get",
        url: url,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            table.className = "table table-bordered";
            var th = "<tr><th>Rate ID</th><th>Rate Date</th><th>Customer</th><th>Shipment Date</th><th>Sales Person</th><th>Shipment Line</th><th>Status</th><th>Agency</th></tr>"
            table.innerHTML = th;
            el("listDetails").innerHTML = "";
            for (var i = response.length - 1; i >= 0; i--) {
                var data = response[i].data;
                var jsonData = hex2a(data);
                var cData = JSON.parse(jsonData);
                txt += "<tr><td>" + cData.RateID + "</td><td>" + cData.RateDate + "</td><td>" + cData.Customer + "</td><td>" + cData.ShipmentDate + "</td><td>" + cData.SalePerson
                    + "</td><td>" + cData.ShipmentLine + "</td><td>" + cData.Satus + "</td><td>" + cData.Agency + "</td><tr>";
            }
            table.innerHTML += txt;
            el("listDetails").appendChild(table);
        },
    });
}

function getListlatestdataRequest() {
    var url = baseURL + "listlatestdatarequest";
    $.ajax({
        type: "Get",
        url: url,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            table.className = "table table-bordered";
            var th = "<tr><th>Rate ID</th><th>Rate Date</th><th>Customer</th><th>Shipment Date</th><th>Sales Person</th><th>Shipment Line</th><th>Status</th><th>Agency</th><th>View</th></tr>"
            table.innerHTML = th;
            el("listDetails").innerHTML = "";
            for (var i = response.length - 1; i >= 0; i--) {
                var data = response[i].data;
                var jsonData = hex2a(data);
                var cData = JSON.parse(jsonData);

                txt += "<tr><td>" + cData.RateID + "</td><td>" + cData.RateDate + "</td><td>" + cData.Customer + "</td><td>" + cData.ShipmentDate + "</td><td>" + cData.SalePerson
                    + "</td><td>" + cData.ShipmentLine + "</td><td>" + cData.Satus + "</td><td>" + cData.Agency + "</td><td><input type=button id=" + cData.RateID + " value='Edit'  onclick='getlistStreamKey_Items(" + cData.RateID + ")'/></td><tr>";
            }
            table.innerHTML += txt;
            el("listDetails").appendChild(table);
        },
    });
}

////////////////////////////////////////////
//view all history in popup from RateRequest
////////////////////////////////////////////
function viewHistory(key) {
    // Get the modal
    var modal = document.getElementById('myModal');
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];
    // When the user clicks the button, open the modal 
    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    modal.style.display = "block";
    var key = { "RateID": key };
    var url = baseURL + "liststreamkeyitems";
    $.ajax({
        type: "POST",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(key),
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            table.className = "table table-bordered";
            var th = "<tr><th>Rate ID</th><th>INCO Terms</th></th></th><th>Agency</th></th></th><th>Status</th><th>TX ID</th></tr>"
            table.innerHTML = th;
            el("tblContent").innerHTML = "";
            for (var i = 0; i < response.length; i++) {
                var data = response[i].data;
                console.log(response[i].data);
                var jsonData = hex2a(data);
                var cData = JSON.parse(jsonData);
                txt += "<tr><td>" + cData.RateID + "</td><td>"
                    + cData.Term + "</td><td>" + cData.Agency
                    + "</td><td>" + cData.Satus
                    + "</td><td>" + response[i].txid + "</td><tr>";

            }
            table.innerHTML += txt;
            el("tblContent").appendChild(table);
        },
    });

}

///////////////////////////////////
// publish data from RateApprove//
//////////////////////////////////
function saveRateOfRequestPublish_approve() {
    var rateID = el("rr_no").value;
    var date = el("rr_date").value;
    var requestBy = el("rr_by").value;
    var customer = el("customer").value;
    var enquiryNO = el("enquiry_no").value;
    var enquiryDate = el("enquiry_date").value;
    var shipment_date = el("shipment_date").value;
    var term = el("inco_terms").value;
    var salePerson = el("sales_persion").value;
    var validFrom = el("valid_from_date").value;
    var validTO = el("valid_to_date").value;
    var agency = el("agency").value;
    var shipper = el("shipper").value;
    var consignee = el("consignee").value;
    var status = el("Status").value;
    var shipmentTerm = el("shipment_term").value;
    var shipmentLine = el("shipment_line").value;
    if (rateID != null) {
        var RateOfRequest = {
            "RateID": rateID, "RateDate": date, "RequestBy": requestBy, "Customer": customer,
            "EnquiryNO": enquiryNO, "EnquiryDate": enquiryDate, "ShipmentDate": shipment_date, "Term": term, "SalePerson": salePerson,
            "ValidFrom": validFrom, "ValidTO": validTO, "Agency": agency, "Shipper": shipper, "Consignee": consignee, "Satus": status,
            "ShipmentTerm": shipmentTerm, "ShipmentLine": shipmentLine
        }
        data = JSON.stringify(RateOfRequest);
        var parseData = stringToHex(data).replace(/\s/g, "");
        //var parseData = stringToHex(data);
        var rateOfReq = { "RateID": rateID, "RefName": rateID, "Address": _address, "EncData": parseData }
        data = JSON.stringify(rateOfReq);

        var url = baseURL + "CreateApprove";
        sendPostData(url, data);
    }
    else {
        alert("No Data");
    }
}

////////////////////////////////
//call from RateApproval
/////////////////////////
function getListlatestdataApproval() {


    var url = baseURL + "listlatestdata";
    $.ajax({
        type: "Get",
        url: url,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            table.className = "table table-bordered";
            var th = "<tr><th>Rate ID</th><th>Rate Date</th><th>Customer</th><th>Shipment Date</th><th>Sales Person</th><th>Shipment Line</th><th>Status</th><th>Agency</th><th>View</th></tr>"
            table.innerHTML = th;
            el("listDetails").innerHTML = "";
            for (var i = response.length - 1; i >= 0; i--) {
                var data = response[i].data;
                var jsonData = hex2a(data);
                var cData = JSON.parse(jsonData);

                txt += "<tr><td>" + cData.RateID + "</td><td>" + cData.RateDate + "</td><td>" + cData.Customer + "</td><td>" + cData.ShipmentDate + "</td><td>" + cData.SalePerson
                    + "</td><td>" + cData.ShipmentLine + "</td><td>" + cData.Satus + "</td><td>" + cData.Agency + "</td><td><input type=button id=" + cData.RateID + " value='View'  onclick='getlistStreamKey_Items(" + cData.RateID + ")'/></td><tr>";
            }
            table.innerHTML += txt;
            el("listDetails").appendChild(table);
        },
    });
}

///////////////////////
//call from client for searching Request
////////////////////

function getlistStreamKey_Items(key) {
    var key = { "RateID": key.id };
    var url = baseURL + "liststreamkeywithitems";
    $.ajax({
        type: "POST",
        url: url,
        async: false,
        data: JSON.stringify(key),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var data = response[response.length - 1].data;
            var jsonDate = hex2a(data);
            var cDate = JSON.parse(jsonDate);
            el("rr_no").value = cDate.RateID;
            el("rr_date").value = cDate.RateDate;
            el("rr_by").value = cDate.RequestBy;
            el("customer").value = cDate.Customer;
            el("enquiry_no").value = cDate.EnquiryNO;
            el("enquiry_date").value = cDate.EnquiryDate;
            el("shipment_date").value = cDate.ShipmentDate;
            el("inco_terms").value = cDate.Term;
            el("sales_persion").value = cDate.SalePerson;
            el("valid_from_date").value = cDate.ValidFrom;
            el("valid_to_date").value = cDate.ValidTO;
            el("agency").value = cDate.Agency;
            el("shipper").value = cDate.Shipper;
            el("consignee").value = cDate.Consignee;
            el("Status").value = cDate.Satus;
            el("shipment_term").value = cDate.ShipmentTerm;
            el("shipment_line").value = cDate.ShipmentLine;
        }
    })

}


function unique_id() {
    var url = baseURL + "ListOfData";
    var rate_no = 0;
    $.ajax({
        type: "Get",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            console.log(response.length);
            if (response.length == null) {
                rate_no = 1;
            }
            else {
                rate_no = response.length + 1;
            }
            el("rr_no").value = "RRAGNMUM" + rate_no;

        },
    });
}


function lastrecord() {
    var url = baseURL + "ListData"
    $.ajax({
        type: "Get",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var data = response[response.length - 1];
            data = data.data;
            var jsonData = hex2a(data);
            var param = JSON.parse(jsonData);
            el("rr_no").value = param.RateID;
            el("rr_date").value = param.RateDate;
            el("rr_by").value = param.RequestBy;
            el("customer").value = param.Customer;
            el("enquiry_no").value = param.EnquiryNO;
            el("enquiry_date").value = param.EnquiryDate;
            el("shipment_date").value = param.shipmentDate;
            el("inco_terms").value = param.Term;
            el("sales_persion").value = param.SalePerson;
            el("valid_from_date").value = param.ValidFrom;
            el("valid_to_date").value = param.ValidTO;
            el("agency").value = param.Agency;
            el("shipper").value = param.Shipper;
            el("consignee").value = param.Consignee;
            el("Status").value = param.Satus;
            el("shipment_term").value = param.ShipmentTerm;
            el("shipment_line").value = param.ShipmentLine;
        }
    });
}



function validation() {
    var shipdate = datevalidation(el("shipment_date").value);
    var fromdate = datevalidation(el("valid_from_date").value);
    var todate = datevalidation(el("valid_to_date").value);
    var validate = datevalidation1(el("valid_from_date").value, el("valid_to_date").value);
    if (el("rr_by").value == null || el("rr_by").value == "") {
        alert("Select RR By filed item in the list");
        return true;
    }
    else if (el("customer").value == null || el("customer").value == "") {
        alert("Select Customer filed item in the list");
        return true;
    }
    else if (el("sales_persion").value == null || el("sales_persion").value == "") {
        alert("Select Slaes Persion filed item in the list");
        return true;
    }
    else if (shipdate == false) {
        //if () {
        alert("Check Shipping Date filed");
        return true;
    }
    else if (fromdate == false) {
        //if () {
        alert("Check Valid From date filed");
        return true;
    }
    else if (validate == false) {
        //if () {
        alert("The valid from date must greater the valid to date");
        return true;
    }
    else if (el("agency").value == null || el("agency").value == "") {
        alert("Select Agency filed item in the list");
        return true;
    }
    else if (el("Status").value == null || el("Status").value == "") {
        alert("Select Status filed item in the list");
        return true;
    }
    else if (el("shipment_date").value == null || el("shipment_date").value == "") {
        alert("Fill Shipment filed");
        return true;
    }

    else {
        return false;
    }
    function datevalidation(date) {
        var set_date = new Date(date);
        var current_date = new Date(setdatevalidation());
        var result = (!(set_date > current_date || current_date > set_date))
        return result;
    }
    function datevalidation1(fromdate, todate) {
        var from_date = new Date(fromdate);
        var to_date = new Date(todate);
        var result = (from_date < to_date && to_date != from_date)
        return result;
    }
}

function dateset() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd
    }

    if (mm < 10) {
        mm = '0' + mm
    }

    today = mm + '/' + dd + '/' + yyyy;
    el("rr_date").value = today;
    el("enquiry_date").value = today;
    el("valid_from_date").value = today;
    el("shipment_date").value = today;
}

function setdatevalidation() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd
    }

    if (mm < 10) {
        mm = '0' + mm
    }

    today = mm + '/' + dd + '/' + yyyy;

    return today;
}


function clear() {
    el("rr_no").value = null;
    el("rr_date").value = null;
    el("rr_by").value = null;
    el("customer").value = null;
    el("enquiry_no").value = null;
    el("enquiry_date").value = null;
    el("shipment_date").value = null;
    el("inco_terms").value = null;
    el("sales_persion").value = null;
    el("valid_from_date").value = null;
    el("valid_to_date").value = null;
    el("agency").value = null;
    el("shipper").value = null;
    el("consignee").value = null;
    el("Status").value = null;
    el("shipment_term").value = null;
    el("shipment_line").value = null;
}



/*


function getData(URL, ID) {
    if (typeof (ID) == "undefined") {
        ID = "";
    }
    $.ajax({
        type: "Get",
        url: URL,
        async: false,
        contentType: "application/json; charset=utf-8",
        data: { "ID": ID },
        success: function (response) {
            el("listDetails").innerText = "";
            for (var i = 0; i < response.length; i++) {
                el("listDetails").innerText = el("listDetails").innerText + "\n" + JSON.stringify(response[i]);
            }
        },
    });
}







function saveRateOfRequest() {
    var rateID = el("rr_no").value;
    var date = el("rr_date").value;
    var requestBy = el("rr_by").value;
    var customer = el("customer").value;
    var enquiryNO = el("enquiry_no").value;
    var enquiryDate = el("enquiry_date").value;
    var shipmentDate = el("shipment_date").value;
    var term = el("inco_terms").value;
    var salePerson = el("sales_persion").value;
    var validFrom = el("valid_from_date").value;
    var validTO = el("valid_to_date").value;
    var agency = el("agency").value;
    var shipper = el("shipper").value;
    var consignee = el("consignee").value;
    var status = el("Status").value;
    var shipmentTerm = el("shipment_term").value;
    var shipmentLine = el("shipment_line").value;
    if (rateID != "") {
        var RateOfRequest = {
            "RateID": rateID, "RateDate": date, "RequestBy": requestBy, "Customer": customer,
            "EnquiryNO": enquiryNO, "EnquiryDate": enquiryDate, "shipmentDate": shipmentDate, "Term": term, "SalePerson": salePerson,
            "ValidFrom": validFrom, "ValidTO": validTO, "Agency": agency, "Shipper": shipper, "Consignee": consignee, "Satus": status,
            "ShipmentTerm": shipmentTerm, "ShipmentLine": shipmentLine
        }

        data = JSON.stringify(RateOfRequest);
        var parseData = stringToHex(data);
        var rateOfReq = { "RateID": rateID, "RefName": rateID, "Address": _address, "EncData": parseData }
        data = JSON.stringify(rateOfReq);

        var url = baseURL + "RateOfRequest";
        sendPostData(url, data);
    }
}

function getListOfAssert() {
    var url = baseURL + "ListOfData";
    getData(url);

}



// function getListOfSteam() {
//     var url = baseURL + "ListOfData";
//     getData(url);
// }


function getListOfSteam() {

   var url = baseURL + "ListOfData";
    $.ajax({
        type: "Get",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            table.className = "table table-bordered";
            var th = "<tr><th>Rate ID</th><th>Rate By</th><th>Customer</th></th><th>Enquiry No</th></th><th>INCO Terms</th></th><th>Sales Person</th></th><th>Agency</th></th><th>Shipper</th></th><th>Consignee</th></th><th>Status</th><th>TX ID</th></tr>"
            table.innerHTML = th;
            el("listDetails").innerHTML = "";
            for (var i = response.length - 1; i >= 0; i--) {
                var data = response[i].data;
                var jsonData = hex2a(data);
                var cData = JSON.parse(jsonData);
                txt += "<tr><td>" + cData.RateID + "</td><td>" + cData.RequestBy + "</td><td>" + cData.Customer + "</td><td>" + cData.EnquiryNO
                    + "</td><td>" + cData.Term + "</td><td>" + cData.SalePerson + "</td><td>" + cData.Agency
                    + "</td><td>" + cData.Shipper + "</td><td>" + cData.Consignee + "</td><td>" + cData.Satus
                    + "</td><td>" + response[i].txid + "</td><tr>";
            }
            table.innerHTML += txt;
            el("listDetails").appendChild(table);
        },
    });
}


function getLastData() {

    // var url = baseURL + "ListOfData";
    // getData(url);

    var url = baseURL + "ListOfData";
    $.ajax({
        type: "Get",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            table.className = "table table-bordered";
            var th = "<tr><th>Rate ID</th><th>Rate By</th><th>Customer</th></th><th>Enquiry No</th></th><th>INCO Terms</th></th><th>Sales Person</th></th><th>Agency</th></th><th>Shipper</th></th><th>Consignee</th></th><th>Status</th><th>TX ID</th></tr>"
            table.innerHTML = th;
            el("listDetails").innerHTML = "";
            for (var i = 0; i < response.length; i++) {
                if (i == response.length - 1) {
                    var data = response[i].data;
                    var jsonData = hex2a(data);
                    var cData = JSON.parse(jsonData);
                    txt += "<tr><td>" + cData.RateID + "</td><td>" + cData.RequestBy + "</td><td>" + cData.Customer + "</td><td>" + cData.EnquiryNO
                        + "</td><td>" + cData.Term + "</td><td>" + cData.SalePerson + "</td><td>" + cData.Agency
                        + "</td><td>" + cData.Shipper + "</td><td>" + cData.Consignee + "</td><td>" + cData.Satus
                        + "</td><td>" + response[i].txid + "</td><tr>";
                }
            }
            table.innerHTML += txt;
            el("listDetails").appendChild(table);
        },
    });
}

//list of data with key from RateRequest page
function ListDataKey() {

    var url = baseURL + "liststreamkeys";


    var key = { "RateID": el("rr_no").value };
    var url = baseURL + "liststreamkeyitems";

    $.ajax({
        type: "POST",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(key),
        success: function (response) {
            var txt = "";
            var table = document.createElement("table");
            var th = "<tr><th>Rate ID</th><th>Rate By</th><th>Customer</th></th><th>Enquiry No</th></th><th>INCO Terms</th></th><th>Sales Person</th></th><th>Agency</th></th><th>Shipper</th></th><th>Consignee</th></th><th>Status</th><th>TX ID</th></tr>"
            table.innerHTML = th;
            el("listDetails").innerHTML = "";
            for (var i = 0; i < response.length; i++) {
                var data = response[i].data;
                var jsonData = hex2a(data);
                var cData = JSON.parse(jsonData);
                txt += "<tr><td>" + cData.RateID + "</td><td>" + cData.RequestBy + "</td><td>" + cData.Customer + "</td><td>" + cData.EnquiryNO
                    + "</td><td>" + cData.Term + "</td><td>" + cData.SalePerson + "</td><td>" + cData.Agency
                    + "</td><td>" + cData.Shipper + "</td><td>" + cData.Consignee + "</td><td>" + cData.Satus
                    + "</td><td>" + response[i].txid + "</td><tr>";
            }
            table.innerHTML += txt;
            el("listDetails").appendChild(table);
        },
    });
}


//Get all data from RateRequest page

*/


/*

//fetch data from RateApproval page
function getlistStreamKey_Items() {
    var key = { "RateID": el("rr_no").value };
    var url = baseURL + "liststreamkeyitems";

    $.ajax({
        type: "POST",
        url: url,
        async: false,
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(key),
        success: function (response) {
            var lenght = response.length;
            var data = response[lenght - 1].data;
            var jsonData = hex2a(data);
            var param = JSON.parse(jsonData);
            el("rr_no").value = param.RateID;
            el("rr_date").value = param.RateDate;
            el("rr_by").value = param.RequestBy;
            el("customer").value = param.Customer;
            el("enquiry_no").value = param.EnquiryNO;
            el("enquiry_date").value = param.EnquiryDate;
            el("shipment_date").value = param.ShipmentDate;
            el("inco_terms").value = param.Term;
            el("sales_persion").value = param.SalePerson;
            el("valid_from_date").value = param.ValidFrom;
            el("valid_to_date").value = param.ValidTO;
            el("agency").value = param.Agency;
            el("shipper").value = param.Shipper;
            el("consignee").value = param.Consignee;
            el("Status").value = param.Satus;
            el("shipment_term").value = param.ShipmentTerm;
            el("shipment_line").value = param.ShipmentLine;
        },
    });

}
*/
/////////////////////////////////////////////////



// function login() {
//     var key = { "username": el("username").value };
//     var url = baseURL + "RateRequest1";
//     $.ajax({
//         type: "Get",
//         url: url,
//         async: false,
//         contentType: "application/json; charset=utf-8",
//         data: JSON.stringify(key),
//         success: function (response) {
//         },
//     });
// }
