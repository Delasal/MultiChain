// var http = require('http');
// var fs = require('fs');
// var server = http.createServer(function (req, res) {
//     if (req.url === '/' || req.url === '/RateRequest') {
//         res.writeHead(200, { 'content-type': 'text/html' });
//         fs.createReadStream(__dirname + './RateRequest.html').pipe(res);
//     }
// });

var bodyParser = require('body-parser');
var cors = require('cors');
var express = require('express');
var path = require('path');
var multichain = require("multichain-node")({
    port: 6277,
    host: 'localhost',
    user: 'vignesh.s',
    pass: '123456'
})


var my_address = "1XHKk4iW2TFvbeysjhQS36GnHuxGkpzLLzkTFs";
var app = express();
app.use(bodyParser.json());
app.use(cors());

app.post('/RateOfRequest', function (req, res) {
    var param = req.body;
    var RateOfRequest = {
        "RateID": param.RateID, "FromAddress": param.Address, "EncData": param.EncData, "RefName": param.RefName
    }

    multichain.issue({ address: param.Address, asset: param.RateID, details: RateOfRequest }, (err, res1) => {
        if (err) {
            throw err;
        }
        res.send(res1)
    })
});


app.post('/CreateRequest', function (req, res) {
    var param = req.body;
    var RateOfRequest = { "RateID": param.RateID, "EncData": param.EncData }
    multichain.publish({
        stream: "iTank",
        key: param.RateID,
        data: param.EncData,
    },
        (err, pub) => {
            if (err) {
                console.log(err);
                throw err;
            }
            res.send(pub);
        })

});

app.get('/ListOfData', function (req, res) {
    multichain.listStreamItems({
        stream: "iTank",
        verbose: false
    },
        (err, pub) => {
            if (err) {
                res.send(err);
            }
            res.send(pub);
        })
});


app.post('/liststreamkeyitems', function (req, res) {
    var param = req.body;
    multichain.listStreamKeyItems({
        stream: "iTank",
        key: param.RateID,
        verbose: false
    },
        (err, pub) => {
            if (err) {
                console.log(err);
                res.send(err);
            }
            res.send(pub);
        })
});


app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/../multichaindemo/RateRequest.html'));
});
test: function test() {
console.log("Function test");
req.send("Hello");
}

module.exports=test;