//import npm modules
var bodyParser = require('body-parser');
var cors = require('cors');
var express = require('express');
var path = require('path');

var router = express.Router();
var app = express();
app.use(bodyParser.json());
app.use(cors());
app.use('/', router);

//import user files
var page = require('./UIpages/page');

//import multichain and connection statment
var multichain = require("multichain-node")({
    port: 7205,
    host: '127.0.0.1',
    user: 'darwin',
    pass: '123456'
})

//use static files js, css
app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/UIpages'));



//calling UI pages
router.get('/', function (req, res) {
    res.sendFile(__dirname + '/UIpages/Home.html');
});
router.get('/home', function (req, res) {
    res.sendFile(__dirname + '/UIpages/Home.html');
});
router.get('/RateRequest', function (req, res) {
    res.sendFile(__dirname + '/UIpages/RateRequest.html');
});

router.get('/RateApproval', function (req, res) {
    res.sendFile(__dirname + '/UIpages/RateApproval.html');
});


app.get('/RateRequest', function (req, res) {
    res.sendFile(__dirname + '/UIpages/RateRequest.html');
})


//Multichain publish method
app.post('/CreateRequest', function (req, res) {
    var param = req.body;
    var RateOfRequest = { "RateID": param.RateID, "EncData": param.EncData }
    multichain.publish({
        stream: "rReq",
        key: param.RateID,
        data: param.EncData,
    },
        (err, pub) => {
            if (err) {
                console.log(err);
                throw err;
            }
            res.send(pub);
        })

});

app.post('/CreateApprove', function (req, res) {
    var param = req.body;
    var RateOfRequest = { "RateID": param.RateID, "EncData": param.EncData }
    multichain.publish({
        stream: "rReq",
        key: param.RateID,
        data: param.EncData,
    },
        (err, pub) => {
            if (err) {
                console.log(err);
                throw err;
            }
            res.send(pub);
        })

});



router.get('/listlatestdata', function (req, res) {
    var pData = "";
    multichain.listStreamKeys({
        stream: "rReq",
        verbose: true,
        start: 0,
        count: 100
    },
        (err, pub) => {
            if (err) {
                console.log(err);
            }
            var data = pub;
            var pData = [];
            for (var i = 0; i < data.length; i++) {
                multichain.listStreamKeyItems({
                    stream: "rReq",
                    key: data[i].key,
                    verbose: false,
                    start: 0,
                    count: 100
                }, (err, res1) => {
                    if (err) {
                        console.log(err);
                    }
                    pData.push(res1[res1.length - 1]);
                })
            }

            setTimeout(function () {
                res.send(pData);
            }, 500);


        })

});

router.get('/listlatestdatarequest', function (req, res) {
    var pData = "";
    multichain.listStreamKeys({
        stream: "rReq",
        verbose: true,
        start: 0,
        count: 100,
        "local-ordering": false
    },
        (err, pub) => {
            if (err) {
                console.log(err);
            }
            var data = pub;
            var pData = [];
            for (var i = 0; i < data.length; i++) {
                multichain.listStreamKeyItems({
                    stream: "rReq",
                    key: data[i].key,
                    verbose: false
                }, (err, res1) => {
                    if (err) {
                        console.log(err);
                    }
                    pData.push(res1[res1.length - 1]);
                })
            }

            setTimeout(function () {
                res.send(pData);
            }, 500);


        })

});

router.post('/liststreamkeywithitems', function (req, res) {
    var param = req.body;
    multichain.listStreamKeyItems({
        stream: "rReq",
        key: param.RateID,
        verbose: false,
        start:0,
        count:9999999999999
    },
        (err, pub) => {
            if (err) {
                console.log(err);
            }
            res.send(pub);
        })
});


app.get('/ListOfData', function (req, res) {
    multichain.listStreamItems({
        stream: "rReq",
        verbose: false,
        start: 0,
        count: 1000
    },
        (err, pub) => {
            if (err) {
                res.send(err);
            }
            res.send(pub);
        })
});

app.get('/ListData', function (req, res) {
    multichain.listStreamItems({
        stream: "rReq",
        verbose: false,
        start: 0,
        count: 1000
    },
        (err, pub) => {
            if (err) {
                res.send(err);
            }
            res.send(pub);
        })
});

/*
// app.get('/RateRequest1', function (req, res) {
//     var param = req.body;
//     console.log(param.username.toString());
//     var username={"username":param.username};
//     console.log(param.username);
//     console.log("hey");
//     var user_name = param.username;
//     var password = param.pass;
//     if (user_name == "admin" && password == "admin") {
//         res.sendFile(__dirname + '/UIpages/RateRequest.html');
//         console.log("hey");
//     }
// });



//Multichain issue method
app.post('/RateOfRequest', function (req, res) {
    var param = req.body;
    var RateOfRequest = {
        "RateID": param.RateID, "FromAddress": param.Address, "EncData": param.EncData, "RefName": param.RefName
    }

    multichain.issue({ address: param.Address, asset: param.RateID, details: RateOfRequest }, (err, res1) => {
        if (err) {
            throw err;
        }
        res.send(res1)
    })
});




//Multichain liststreamkeyitems method 


*/



app.listen(8000);
console.log("Server Started");