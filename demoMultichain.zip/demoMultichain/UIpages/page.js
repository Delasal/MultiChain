var express = require('express')

var router = express.Router();

router.get('/', function (req, res) {
    res.sendFile(__dirname + '/Home.html');
});
router.get('/RatRequest', function (req, res) {
    res.sendFile(__dirname + '/RatRequest.html');
});
router.get('/RatApproval', function (req, res) {
    res.sendFile(__dirname + '/RatApproval.html');
});

module.exports = router;